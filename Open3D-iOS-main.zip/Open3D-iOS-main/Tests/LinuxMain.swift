import XCTest

import Open3D_iOSTests

var tests = [XCTestCaseEntry]()
tests += Open3D_iOSTests.allTests()
XCTMain(tests)
